/* poop.c 63168 burner - made by Matt Goring - Feb 2015 */

#include "sysdep.h"
#include <stdio.h>
#include <string.h>
#include <cmd.h>
#include <../bus/ejtag.c> // yeah, i know



/* GPL - 6316_map_part.h */
#define PERF_BASE            0xb0000000  /* chip control registers */
#define TIMR_BASE            0xb0000040  /* timer registers */
#define GPIO_BASE            0xb0000080  /* gpio registers */
#define UART_BASE            0xb0000100  /* uart registers */
#define UART1_BASE           0xb0000120  /* uart registers */
#define I2C_BASE             0xb0000180  // hmmm, maybe not a I2C...
#define SPI_BASE             0xb0000800  /* SPI master controller registers */
#define HSSPIM_BASE          0xb0001000  /* High-Speed SPI registers */
#define MISC_BASE            0xb0001800  /* Miscellaneous Registers */
#define NAND_REG_BASE        0xb0002000  /* NAND registers */
#define MPI_BASE             0xb00020A0  /* MPI control registers */
#define NAND_CACHE_BASE      0xb0002200
#define USB_CTL_BASE         0xb0002400  /* USB 2.0 device control registers */
#define USB_EHCI_BASE        0x10002500  /* USB host registers */
#define USB_OHCI_BASE        0x10002600  /* USB host registers */
#define USBH_CFG_BASE        0xb0002700
#define DDR_BASE             0xb0003000  /* Memory control registers */
#define GPON_SERDES_BASE     0xb0004800  /* GPON SERDES Interface Registers */
/*
// 0xB0001000
#define	__mask(end, start)		(((1 << ((end - start) + 1)) - 1) << start)
typedef struct HsSpiControl {
  uint32_t	hs_spiGlobalCtrl;	// 0xB0001000
#define	HS_SPI_MOSI_IDLE		(1 << 18)
#define	HS_SPI_CLK_STATE_GATED		(1 << 17)
#define	HS_SPI_CLK_GATE_SSOFF		(1 << 16)
#define	HS_SPI_PLL_CLK_CTRL		(8)
#define	HS_SPI_PLL_CLK_CTRL_MASK	__mask(15, HS_SPI_PLL_CLK_CTRL)
#define	HS_SPI_SS_POLARITY		(0)
#define	HS_SPI_SS_POLARITY_MASK		__mask(7, HS_SPI_SS_POLARITY)
  uint32_t	hs_spiExtTrigCtrl;	// 0xB0001004
#define	HS_SPI_TRIG_RAW_STATE		(24)
#define	HS_SPI_TRIG_RAW_STATE_MASK	__mask(31, HS_SPI_TRIG_RAW_STATE)
#define	HS_SPI_TRIG_LATCHED		(16)
#define	HS_SPI_TRIG_LATCHED_MASK	__mask(23, HS_SPI_TRIG_LATCHED)
#define	HS_SPI_TRIG_SENSE		(8)
#define	HS_SPI_TRIG_SENSE_MASK		__mask(15, HS_SPI_TRIG_SENSE)
#define	HS_SPI_TRIG_TYPE		(0)
#define	HS_SPI_TRIG_TYPE_MASK		__mask(7, HS_SPI_TRIG_TYPE)
#define	HS_SPI_TRIG_TYPE_EDGE		(0)
#define	HS_SPI_TRIG_TYPE_LEVEL		(1)
  uint32_t	hs_spiIntStatus;	// 0xB0001008
#define	HS_SPI_IRQ_PING1_USER		(28)
#define	HS_SPI_IRQ_PING1_USER_MASK	__mask(31, HS_SPI_IRQ_PING1_USER)
#define	HS_SPI_IRQ_PING0_USER		(24)
#define	HS_SPI_IRQ_PING0_USER_MASK	__mask(27, HS_SPI_IRQ_PING0_USER)

#define	HS_SPI_IRQ_PING1_CTRL_INV	(1 << 12)
#define	HS_SPI_IRQ_PING1_POLL_TOUT	(1 << 11)
#define	HS_SPI_IRQ_PING1_TX_UNDER	(1 << 10)
#define	HS_SPI_IRQ_PING1_RX_OVER	(1 << 9)
#define	HS_SPI_IRQ_PING1_CMD_DONE	(1 << 8)

#define	HS_SPI_IRQ_PING0_CTRL_INV	(1 << 4)
#define	HS_SPI_IRQ_PING0_POLL_TOUT	(1 << 3)
#define	HS_SPI_IRQ_PING0_TX_UNDER	(1 << 2)
#define	HS_SPI_IRQ_PING0_RX_OVER	(1 << 1)
#define	HS_SPI_IRQ_PING0_CMD_DONE	(1 << 0)
  uint32_t	hs_spiIntStatusMasked;	// 0xB000100C
#define	HS_SPI_IRQSM__PING1_USER	(28)
#define	HS_SPI_IRQSM__PING1_USER_MASK	__mask(31, HS_SPI_IRQSM__PING1_USER)
#define	HS_SPI_IRQSM__PING0_USER	(24)
#define	HS_SPI_IRQSM__PING0_USER_MASK	__mask(27, HS_SPI_IRQSM__PING0_USER)

#define	HS_SPI_IRQSM__PING1_CTRL_INV	(1 << 12)
#define	HS_SPI_IRQSM__PING1_POLL_TOUT	(1 << 11)
#define	HS_SPI_IRQSM__PING1_TX_UNDER	(1 << 10)
#define	HS_SPI_IRQSM__PING1_RX_OVER	(1 << 9)
#define	HS_SPI_IRQSM__PING1_CMD_DONE	(1 << 8)

#define	HS_SPI_IRQSM__PING0_CTRL_INV	(1 << 4)
#define	HS_SPI_IRQSM__PING0_POLL_TOUT	(1 << 3)
#define	HS_SPI_IRQSM__PING0_TX_UNDER	(1 << 2)
#define	HS_SPI_IRQSM__PING0_RX_OVER	(1 << 1)
#define	HS_SPI_IRQSM__PING0_CMD_DONE	(1 << 0)
  uint32_t	hs_spiIntMask;		// 0xB0001010
#define	HS_SPI_IRQM_PING1_USER		(28)
#define	HS_SPI_IRQM_PING1_USER_MASK	__mask(31, HS_SPI_IRQM_PING1_USER)
#define	HS_SPI_IRQM_PING0_USER		(24)
#define	HS_SPI_IRQM_PING0_USER_MASK	__mask(27, HS_SPI_IRQM_PING0_USER)

#define	HS_SPI_IRQM_PING1_CTRL_INV	(1 << 12)
#define	HS_SPI_IRQM_PING1_POLL_TOUT	(1 << 11)
#define	HS_SPI_IRQM_PING1_TX_UNDER	(1 << 10)
#define	HS_SPI_IRQM_PING1_RX_OVER	(1 << 9)
#define	HS_SPI_IRQM_PING1_CMD_DONE	(1 << 8)

#define	HS_SPI_IRQM_PING0_CTRL_INV	(1 << 4)
#define	HS_SPI_IRQM_PING0_POLL_TOUT	(1 << 3)
#define	HS_SPI_IRQM_PING0_TX_UNDER	(1 << 2)
#define	HS_SPI_IRQM_PING0_RX_OVER	(1 << 1)
#define	HS_SPI_IRQM_PING0_CMD_DONE	(1 << 0)

#define HS_SPI_INTR_CLEAR_ALL       (0xFF001F1F)
  uint32_t	hs_spiFlashCtrl;	// 0xB0001014
#define	HS_SPI_FCTRL_MB_ENABLE		(23)
#define	HS_SPI_FCTRL_SS_NUM			(20)
#define	HS_SPI_FCTRL_SS_NUM_MASK	__mask(22, HS_SPI_FCTRL_SS_NUM)
#define	HS_SPI_FCTRL_PROFILE_NUM	(16)
#define	HS_SPI_FCTRL_PROFILE_NUM_MASK	__mask(18, HS_SPI_FCTRL_PROFILE_NUM)
#define	HS_SPI_FCTRL_DUMMY_BYTES	(10)
#define	HS_SPI_FCTRL_DUMMY_BYTES_MASK	__mask(11, HS_SPI_FCTRL_DUMMY_BYTES)
#define	HS_SPI_FCTRL_ADDR_BYTES		(8)
#define	HS_SPI_FCTRL_ADDR_BYTES_MASK	__mask(9, HS_SPI_FCTRL_ADDR_BYTES)
#define	HS_SPI_FCTRL_ADDR_BYTES_2	(0)
#define	HS_SPI_FCTRL_ADDR_BYTES_3	(1)
#define	HS_SPI_FCTRL_ADDR_BYTES_4	(2)
#define	HS_SPI_FCTRL_READ_OPCODE	(0)
#define	HS_SPI_FCTRL_READ_OPCODE_MASK	__mask(7, HS_SPI_FCTRL_READ_OPCODE)
  uint32_t	hs_spiFlashAddrBase;	// 0xB0001018
  char		fill0[0x80 - 0x18];
  uint32_t	hs_spiPP_0_Cmd;		// 0xB0001080
#define	HS_SPI_PP_SS_NUM		(12)
#define	HS_SPI_PP_SS_NUM_MASK		__mask(14, HS_SPI_PP_SS_NUM)
#define	HS_SPI_PP_PROFILE_NUM		(8)
#define	HS_SPI_PP_PROFILE_NUM_MASK	__mask(10, HS_SPI_PP_PROFILE_NUM)
} HsSpiControl;
*/
typedef struct HsSpiPingPong {	// 0xB0001080
	uint32_t command;		// 80
#define HS_SPI_SS_NUM (12)
#define HS_SPI_PROFILE_NUM (8)
#define HS_SPI_TRIGGER_NUM (4)
#define HS_SPI_COMMAND_VALUE (0)
    #define HS_SPI_COMMAND_NOOP (0)
    #define HS_SPI_COMMAND_START_NOW (1)
    #define HS_SPI_COMMAND_START_TRIGGER (2)
    #define HS_SPI_COMMAND_HALT (3)
    #define HS_SPI_COMMAND_FLUSH (4)
	uint32_t status;		// 84
#define HS_SPI_ERROR_BYTE_OFFSET (16)
#define HS_SPI_WAIT_FOR_TRIGGER (2)
#define HS_SPI_SOURCE_BUSY (1)
#define HS_SPI_SOURCE_GNT (0)
	uint32_t fifo_status;	// 88
	uint32_t control;
} HsSpiPingPong;

typedef struct HsSpiProfile { // 0xb0001100
	uint32_t clk_ctrl;
#define HS_SPI_ACCUM_RST_ON_LOOP (15)
#define HS_SPI_SPI_CLK_2X_SEL (14)
#define HS_SPI_FREQ_CTRL_WORD (0)
	uint32_t signal_ctrl; // 0x04
// 14 & 15 & 16 needs setting
#define	HS_SPI_LAUNCH_RISING   (1 << 13)
#define	HS_SPI_LATCH_RISING    (1 << 12)
	uint32_t mode_ctrl; // 0x08
#define HS_SPI_PREPENDBYTE_CNT (24)
#define HS_SPI_MODE_ONE_WIRE (20)
#define HS_SPI_MULTIDATA_WR_SIZE (18)
#define HS_SPI_MULTIDATA_RD_SIZE (16)
#define HS_SPI_MULTIDATA_WR_STRT (12)
#define HS_SPI_MULTIDATA_RD_STRT (8)
#define HS_SPI_FILLBYTE (0)
	uint32_t polling_config;	// 0x0c
	uint32_t polling_and_mask;	// 0x10
	uint32_t polling_compare;	// 0x14
	uint32_t polling_timeout;	// 0x18
	uint32_t reserved;
} HsSpiProfile;

#define HS_SPI_OP_CODE 13
    #define HS_SPI_OP_SLEEP (0)
    #define HS_SPI_OP_READ_WRITE (1)
    #define HS_SPI_OP_WRITE (2)
    #define HS_SPI_OP_READ (3)
    #define HS_SPI_OP_SETIRQ (4)

#define	HS_SPI ((volatile HsSpiControl * const) HSSPIM_BASE)
#define	HS_SPI_PINGPONG0 ((volatile HsSpiPingPong * const) (HSSPIM_BASE+0x80))
#define	HS_SPI_PINGPONG1 ((volatile HsSpiPingPong * const) (HSSPIM_BASE+0xc0))
#define	HS_SPI_PROFILES  ((volatile HsSpiProfile  * const) (HSSPIM_BASE+0x100))
#define	HS_SPI_FIFO0 ((volatile uint8_t * const) (HSSPIM_BASE+0x200))
#define	HS_SPI_FIFO1 ((volatile uint8_t * const) (HSSPIM_BASE+0x400))



/* GPL - bcmHsSpi.c */
#define HS_SPI_PROFILE_MM     0
#define HS_SPI_PROFILE_PP0    1
#define HS_SPI_PROFILE_PP1    2

#define LEG_SPI_BUS_NUM  0
#define HS_SPI_BUS_NUM   1



/* GPL - spiflash.c / Spansion flash datasheet */
#define FLASH_WRST          0x01    /* write status register */
#define FLASH_PROG          0x02    /* program data into memory array */
#define FLASH_READ          0x03    /* read data from memory array */
#define FLASH_WRDI          0x04    /* reset write enable latch */
#define FLASH_RDSR          0x05    /* read status register */
#define FLASH_WREN          0x06    /* set write enable latch */
#define FLASH_RDSR2         0x07
#define FLASH_READ_FAST     0x0B    /* read data from memory array */
#define FLASH_SERASE        0x20    /* erase one sector in memory array */
#define FLASH_RCR           0x35    /* read config register in memory array */

#define SR_WPEN             0x80
#define SR_BP4              0x40
#define SR_BP3              0x20
#define SR_BP2              0x10
#define SR_BP1              0x08
#define SR_BP0              0x04
#define SR_WEN              0x02
#define SR_RDY              0x01


/*
#define MIPS_BASE_BOOT  0xbfa00000 (0x02A07000)
#define MIPS_BASE       0xff400000 (0x00400000) other (0x02A07000)
bus_read(0xbfa0001c) = 0x00400000
bus_read(0xbfa00020) = 0x1FA00000
*/


uint8_t devId = 0;
static void SendCmd( int ReadWrite, int OpCode, int nBytes, int addr);



static int
cmd_poop_run( chain_t *chain, char *params[] )
{
	//uint32_t OPcode = 0;
	int i, c; //, nbytes = 4;
	
	
	
	if (cmd_params( params ) != 3) {
		return -1;
	}
	if (cmd_get_number( params[1], &devId )) {
		return -1;
	}
	
	
	uint32_t val; //, adr, rnd;
	bus_area_t area;
	bus_prepare( bus );
	bus_area( bus, 0xb0000000, &area );
	
	
	
	
	
	// Flash Reset - gets it out of multi wire mode
	SendCmd(HS_SPI_OP_READ, 0xFF, 1, -1); // Mode Bit Reset
	SendCmd(HS_SPI_OP_READ, 0xF0, 1, -1); // Software Reset
	//SendCmd(HS_SPI_OP_READ, 0x9f, 31, -1);
	
	
	
	
	
	// Flash ID (by changing the read opcode)
	bus_write( bus, 0xb0001000 | 0x14, 0x90 ); // Op Code
	val = bus_read( bus, 0xb8000000 );
	printf("Flash ID: 0x%04x\n", val & 0xFFFF );
	if ( (val & 0xFFF0) != 0x0110 ) {
		printf("   Hmmm, unexpected flash\n");
	}
	bus_write( bus, 0xb0001000 | 0x14, 0x50B ); // Back to Single Wire Fast Read
	
	
	
	
	
	// MISC Settings
	//bus_write( bus, 0xb0001810, 0x2 );
	//bus_write( bus, 0xb000181c, 0x80af0024 );
	bus_write( bus, 0xb000181c, ( bus_read( bus, 0xb000181c ) & 0xFFFCFF00 ) | 0x30024 );
	bus_write( bus, 0xb0001820, ( bus_read( bus, 0xb0001820 ) & 0xFFFC0000 ) | 0x0FA7D );
	bus_write( bus, 0xb0001824,   bus_read( bus, 0xb0001824 ) | 0x00000080 );
	bus_write( bus, 0xb000181c,   bus_read( bus, 0xb000181c ) | 0x80000000 ); // Back again
	bus_write( bus, 0xb0001800,   bus_read( bus, 0xb0001800 ) & 0xFFFFFFFC );
	bus_write( bus, 0xb00000c4, ( bus_read( bus, 0xb00000c4 ) & 0xFFFFFFBF ) | 0x4 ); // GPIO
	bus_write( bus, 0xb00000cc,   bus_read( bus, 0xb00000cc ) & 0xFFFFFFFB );
	bus_write( bus, 0xBFA0001C,   bus_read( bus, 0xBFA0001C ) | 0xC0000000 ); // Feck knows, helps with ram
	bus_write( bus, 0xBFA00020,   0xFFF80001 );
	//bus_write( bus, 0xB0000184,   0x1C );
	
	
	
	// Stop Watchdog ? hopefully
	bus_write( bus, 0xb000009c, 0 );
	
	
	
	// RAM Settings
	/*
	bus_write( bus, 0xb0003000, 0x0 );
	bus_write( bus, 0xb0003004, 0x0 );
	bus_write( bus, 0xb0003008, 0x8 );
	bus_write( bus, 0xb0003100, 0x0000030D );
	bus_write( bus, 0xb0003104, 0x05200008 );
	bus_write( bus, 0xb0003108, 0x00000200 );
	bus_write( bus, 0xb000310c, 0x00005000 );
	bus_write( bus, 0xb0003110, 0x00000200 );
	bus_write( bus, 0xb0003114, 0x00465666 );
	bus_write( bus, 0xb0003118, 0x122C1415 );
	bus_write( bus, 0xb000311c, 0x00004045 );
	// DDR Phy Control
	bus_write( bus, 0xb0003200, 0x00000100 );
	bus_write( bus, 0xb0003204, 0x00000000 );
	bus_write( bus, 0xb0003210, 0x00000000 );
	bus_write( bus, 0xb0003214, 0x00000000 );
	bus_write( bus, 0xb0003218, 0x02003111 );
	bus_write( bus, 0xb000321c, 0x02000000 );
	bus_write( bus, 0xb0003220, 0x200005C0 );
	bus_write( bus, 0xb0003224, 0x00000015 );
	bus_write( bus, 0xb0003230, 0x0001000B );
	bus_write( bus, 0xb0003234, 0x00000000 );
	bus_write( bus, 0xb0003238, 0x00000122 );
	bus_write( bus, 0xb000323c, 0x74550000 );
	bus_write( bus, 0xb0003240, 0x00000005 );
	// 0x300
	uint32_t three[] = {	0x00000100,0x00000003,0x00000782,0x00000782,
							0x00000000,0x00000000,0x00010011,0x00000000,
							0x00000000,0x00000000,0x00000000,0x00000000,
							0x0000010A,0x00000000,0x00000000,0x000A626A,
							0x00000000,0x00000000,0x00000000,0x00000000, };
	// 0x400
	uint32_t four[] = {		0x00000100,0x00000003,0x00000782,0x00000782,
							0x00000000,0x00000000,0x00010011,0x00000000,
							0x00000000,0x00000000,0x00000000,0x00000000,
							0x0000010A,0x00000000,0x00000000,0x000A626A,
							0x00000000,0x00000001,0x00000000,0x00000000, };
	// 0x800
	uint32_t eight[] = {	0x00214577,0x10000000,0x00000000,0x0004FFFF,
							0x00000001,0x00144050,0x0014407F,0x00130000,
							0x00130000,0x0000405C,0x00004085,0x00000000,
							0x00000000,0x37781C8B,0x00000000,0x00018522, };
							//AA,AA,55,55,00,00,10,00,00,00,00,00,00,00,00,01,
							//00,01,00,00,35,6E,D8,7A,B8,49,4C,AE,D3,2D,D6,EB,
							//D0,E8,20,18,6A,DD,B1,F5,70,12,99,5D,A6,5B,AD,C7,
							//A1,D0,40,30,A1,D0,40,30,A1,D0,40,30,A1,D0,40,30,
							//A1,D0,40,30,00,01,80,01,00,00,00,00,25,0E,4A,F6,
							//33,78,1C,CB,00,00,00,00,00,00,00,00,00,00,00,00,
	for (i=0; i<sizeof(three); i++) {
		bus_write( bus, 0xb0003300 | (i*4), three[i] );
	};
	for (i=0; i<sizeof(four);  i++) {
		bus_write( bus, 0xb0003400 | (i*4),  four[i] );
	};
	for (i=0; i<sizeof(eight); i++) {
		bus_write( bus, 0xb0003800 | (i*4), eight[i] );
	};
	*/
	
	
	/*
	bus_write( bus, 0xb000310c, 0x0001FC00 );
	bus_write( bus, 0xb000323c, 0x04000000 );
	bus_write( bus, 0xb0003304, 0x0 );
	bus_write( bus, 0xb0003404, 0x0 );
	bus_write( bus, 0xb0003304, 0x3 );
	bus_write( bus, 0xb0003404, 0x3 );
	
	int tmp = ( ( bus_read( bus, 0xb0003308 ) & 0x1F00 ) >> 8 ) + 0xa;
	if ( 0x1f < tmp ) { tmp = 0x1f; }
	bus_write( bus, 0xb0003318, tmp | 0x10000 );
	
	    tmp = ( ( bus_read( bus, 0xb0003408 ) & 0x1F00 ) >> 8 ) + 0xa;
	if ( 0x1f < tmp ) { tmp = 0x1f; }
	bus_write( bus, 0xb0003418, tmp | 0x10000 );
	
	    tmp = ( ( bus_read( bus, 0xb0003308 ) & 0x1F00 ) >> 8 ) + 0x4;
	if ( 0x1f < tmp ) { tmp = 0x1f; }
	bus_write( bus, 0xb0003230, tmp | 0x110000 );
	
	bus_write( bus, 0xb0003100, 0xc );
	bus_write( bus, 0xb000380c, bus_read( bus, 0xb000380c ) | 0x40000 );
	bus_write( bus, 0xb0003444, 0x1 );
	// hmmm
	
	bus_write( bus, 0xb0003240, bus_read( bus, 0xb0003240 ) | 0x4 );
	bus_write( bus, 0xb0003340, bus_read( bus, 0xb0003340 ) & 0xFFFFFFFC );
	bus_write( bus, 0xb0003440, bus_read( bus, 0xb0003440 ) & 0xFFFFFFFC );
	bus_write( bus, 0xb0003104, 0x05200008 ); //
	bus_write( bus, 0xb0003114, 0x00465666 ); //
	bus_write( bus, 0xb0003118, 0x122C1415 ); //
	bus_write( bus, 0xb000311c, 0x00004045 ); //
	bus_write( bus, 0xb0003134, 0x00000100 );
	bus_write( bus, 0xb0003110, 0x00000104 );
	bus_write( bus, 0xb0003100, 0x00000305 );
	bus_write( bus, 0xb0003100, 0x00000302 );
	bus_write( bus, 0xb0003108, 0x0 );
	bus_write( bus, 0xb0003100, 0x00000308 );
	bus_write( bus, 0xb0003100, 0x00000309 );
	bus_write( bus, 0xb0003100, 0x00000300 );
	bus_write( bus, 0xb0003100, 0x00000301 );
	bus_write( bus, 0xb0003100, 0x00000302 );
	bus_write( bus, 0xb0003100, 0x00000303 );
	bus_write( bus, 0xb0003100, 0x00000303 );
	bus_write( bus, 0xb0003104, bus_read( bus, 0xb0003104 ) & 0xFEFFFFFF );
	bus_write( bus, 0xb0003100, 0x00000301 );
	bus_write( bus, 0xb0003100, 0x00000300 );
	bus_write( bus, 0xb0003104, bus_read( bus, 0xb0003104 ) & 0xFFFFFC7F );
	bus_write( bus, 0xb0003100, 0x00000300 );
	
	bus_write( bus, 0xb0003240, ( bus_read( bus, 0xb0003240 ) & 0xFFFFFFF5 ) | 0x5 );
	bus_write( bus, 0xb0003340,   bus_read( bus, 0xb0003340 ) & 0xFFFFFFF4 );
	bus_write( bus, 0xb0003440,   bus_read( bus, 0xb0003440 ) & 0xFFFFFFF4 );
	bus_write( bus, 0xb0003104, 0x05200008 ); //
	bus_write( bus, 0xb0003104, 0x05200008 ); //
	bus_write( bus, 0xb0003108, 0x00000200 ); //
	bus_write( bus, 0xb0003114, 0x00465666 ); //
	bus_write( bus, 0xb0003118, 0x122C1415 ); //
	bus_write( bus, 0xb0003104, 0x05200008 ); //
	bus_write( bus, 0xb000311c, 0x00004045 ); //
	bus_write( bus, 0xb0003134, 0x00000101 );
	bus_write( bus, 0xb0003100, 0x00000311 );
	bus_write( bus, 0xb0003100, 0x00000305 );
	bus_write( bus, 0xb0003100, 0x00000308 );
	bus_write( bus, 0xb0003100, 0x00000309 );
	bus_write( bus, 0xb0003100, 0x00000300 );
	bus_write( bus, 0xb0003100, 0x00000301 );
	bus_write( bus, 0xb0003100, 0x0000030D );
	bus_write( bus, 0xb0003100, 0x00000304 );
	bus_write( bus, 0xb0003444, 0 );
	bus_write( bus, 0xb0003100, 0x0000000C );
	
	bus_write( bus, 0xb0003118, ( bus_read( bus, 0xb0003118 ) & 0xFFFFC0FF ) | 0x5 );
	*/
	
	/*
	// MISC Settings again
	bus_write( bus, 0xb000181c, ( bus_read( bus, 0xb000181c ) & 0xFFFCFF00 ) | 0x30024 );
	bus_write( bus, 0xb0001820, ( bus_read( bus, 0xb0001820 ) & 0xFFFC0000 ) | 0x0FA7D );
	bus_write( bus, 0xb0001824,   bus_read( bus, 0xb0001824 ) | 0x00000080 );
	bus_write( bus, 0xb000181c,   bus_read( bus, 0xb000181c ) | 0x80000000 ); // Back again
	bus_write( bus, 0xb0001800,   bus_read( bus, 0xb0001800 ) & 0xFFFFFFFC );
	bus_write( bus, 0xb00000c4, ( bus_read( bus, 0xb00000c4 ) & 0xFFFFFFBF ) | 0x4 ); // GPIO
	bus_write( bus, 0xb00000cc,   bus_read( bus, 0xb00000cc ) & 0xFFFFFFFB );
	*/
	
	
	
	/*
	// Poke
	adr = 0xA0601010;
	rnd = rand();
	bus_write( bus, adr, rnd );
	// Peek
	val = bus_read( bus, adr );
	printf("write rand() & bus_read(0x%08x) = 0x%08X (%i)\n", adr, val, val );
	if (val != rnd)
	{
		printf("RAM Error, need some 0xB0003000 settings.\n"); // slow
		return 1;
	}
	*/
	
	
	/*
	// zapp some Ram to 1's
	printf("Clearing some RAM...\n");
	uint32_t code[] = {
		0x3c085555,	// lui $8/t0, -1
		0x3508aaaa,	// ori $8/t0, -1
		0x3c090000 | 0x8000,	// lui $9/t1, adr_hi
			0x3c0a0000 | 0x8001,	// lui $10/t2, adr_hi
			//0x354a0000 | 0x1000,	// ori $10/t2, -1
		0xad280000,	// sw $8/t0, 0($9/t1)
		0x25290004,	// addiu $9, $9, 4
		0x152aFFFD,	// bne $9, $10, up-2-lines
		0x0,	// nop
		0x03e00008,	// jr $31/ra
		0x0,	// nop
	};
	// 64K takes 2:07 !!!   128K takes 4:09 !!!
	ejtag_run_pracc( bus, code, (sizeof(code) / 4) );
	printf("Done\n");
	*/
	
	
	
	
	
	// Get File details
	FILE *fd;
	int fylesize, fylesizeblock = 0;
	
	fd = fopen( params[2], "r" );
	if (!fd) {
		printf("Unable to open file '%s'\n", params[2] );
		return 1;
	}
	
	fseek(fd, 0, SEEK_END);
	fylesize = ftell( fd );	// File size
	fylesizeblock = ((fylesize + 65535) / 65536) * 65536;
	fseek(fd, 0, SEEK_SET);
	
	uint8_t filecont[ fylesizeblock +2 ];		// HalfWord overhang
	for (i = fylesize; i < fylesizeblock +2; i++)	// Fill in a few 0xFF's
	{
		filecont[ i ] = 0xff;
	}
	fread( filecont, 1, fylesize, fd );
	
	fclose( fd );
	
	
	
	
	
	// Flash Stuff
	for (c = 0; c < fylesize; c += 0x10000) // 64K Block Size
	{
		// Enable Write
		SendCmd(HS_SPI_OP_WRITE, FLASH_WREN, 1, -1); // 0x6
		SendCmd(HS_SPI_OP_READ,  FLASH_RDSR, 1, -1); // 0x5 Status Reg
		if ( (bus_read( bus, 0xb0001200 ) >> 24) && SR_WEN ) // 0x2
		{
			printf("Status Reg = Write\n");
		} else {
			printf("Status Reg = No Write, is it protected?\n");
			return 1;
		}
		// Erase
		printf("Erasing Block 0x%x\n", c);
		SendCmd(HS_SPI_OP_WRITE, 0xD8, 1+3, c); // Block Erase (Sector=0x20)
		i = 0;
		while ( (bus_read( bus, 0xb0001200 ) >> 24) && SR_RDY) // 0x1
		{
			SendCmd(HS_SPI_OP_READ, FLASH_RDSR, 1, -1); // 0x5 Status Reg
			if (i > 1000)
			{
				printf("Timeout Error: Waiting for WIP bit in Status Reg 1\n");
				return 1;
			}
			i++;
		}
	}
	
	
	
	
	
	// Upload & Write
	printf("Uploading & Writing file... (%d) (<=%dK)\n", fylesize, fylesizeblock / 1024);
	/* This test appears to crash/hang the router
	uint32_t code[] = {
		0x3c088000, // lui     $8,  0x8000 # ram
		0x35080000, // ori     $8,  0x0000
		0x3c09FF20, // lui     $9,  0xFF20 # scratchpad
		0x35290200, // ori     $9,  0x0200
		0x3c0aFF20, // lui     $10, 0xFF20 # scratchpad limit
		0x354a0210, // ori     $10, 0x0210
		0x8d2b0000, // lw      $11, 0($9)
		0xad0b0000, // sw      $11, 0($8)
		0x25080004, // addiu   $8, $8, 1
		0x25290004, // addiu   $9, $9, 1
		0x152aFFFB,	// bne     $9, $10, up-4-lines(lw)
		0x0,		// nop
		0x03e00008,	// jr $31/ra
		0x0,		// nop
		0xAAAAAAAA,
		0x55555555,
		0x12345678,
		0x87654321,
		0x0,
	};
	*/
	
	
	/* Example shit upload, 4 usefull bytes of every 12 (under 1K of code)
	uint32_t code[] = {
		0x3c088000, // lui     $8, 0x8000 # ram
		0x35080000, // ori     $8, 0x0000
		0x3c09AAAA, // lui     $9, 0xAAAA # value
		0x35295555, // ori     $9, 0x5555 # value
		0xad090000, // sw      $9, 0($8)
		0x3c091234, // lui     $9, 0x1234 # value
		0x35295678, // ori     $9, 0x5678 # value
		0xad090004, // sw      $9, 4($8)
		0x03e00008,	// jr      $31
		0x0,		// nop
	};
	*/
	
	
	int fcnt = 0, WordBlock;
	uint32_t code[0x120];
	
	while (fcnt < fylesizeblock)
	{
		// Enable Write
		SendCmd(HS_SPI_OP_WRITE, FLASH_WREN, 1, -1); // 0x6
		SendCmd(HS_SPI_OP_READ,  FLASH_RDSR, 1, -1); // 0x5 Status Reg
		i = 0;
		while ( ((bus_read( bus, 0xb0001200 ) >> 24) && SR_WEN) == 0 ) // 0x2
		{
			//printf("8\n");
			SendCmd(HS_SPI_OP_READ, FLASH_RDSR, 1, -1); // 0x5 Status Reg
			if (i > 100)
			{
				printf("Timeout Error: Waiting for WEL bit in Status Reg 1\n");
				return 1;
			}
			i++;
		}
		
		
		c = 0;
		code[c++] = 0x3c08B000;	// lui $8, 0xB000 # FIFO
		code[c++] = 0x35081200;	// ori $8, 0x1200
		// Write Twice !
		code[c++] = 0x3c090000 | (HS_SPI_OP_WRITE << HS_SPI_OP_CODE) | (1+3+0x100);		// lui $9, 0xAAAA # value
		code[c++] = 0x35290000 | (FLASH_PROG << 8) | (fcnt >> 16);						// ori $9, 0x5555 # value
		code[c++] = 0xad090000;	// sw $9, 0($8)
		code[c++] = 0xad090000;	// sw $9, 0($8)
		code[c++] = 0x3c090000 | (fcnt & 0xFFFF);								// lui $9, 0xAAAA # value
		code[c++] = 0x35290000 | (filecont[fcnt++] << 8) | filecont[fcnt++];	// ori $9, 0x5555 # value
		code[c++] = 0xad090004;	// sw $9, 4($8)
		code[c++] = 0xad090004;	// sw $9, 4($8)
		WordBlock = 8;
		
		while ( (c < 0x10a) && (fcnt < fylesizeblock) )
		{
			if (c < 0x106)
			{
				// Full Word
				code[c++] = 0x3c090000 | (filecont[fcnt++] << 8) | filecont[fcnt++];	// lui $9, 0xAAAA # value
				code[c++] = 0x35290000 | (filecont[fcnt++] << 8) | filecont[fcnt++];	// ori $9, 0x5555 # value
				code[c++] = 0xad090000 | WordBlock;	// sw $9, x($8)
				code[c++] = 0xad090000 | WordBlock;	// sw $9, x($8)
				WordBlock += 4;
			} else {
				// last Half Word
				code[c++] = 0x3c090000;													// lui $9, 0xAAAA # value
				code[c++] = 0x35290000 | (filecont[fcnt++] << 8) | filecont[fcnt++];	// ori $9, 0x5555 # value
				code[c++] = 0xa5090000 | WordBlock;	// sh $9, x($8)
				code[c++] = 0xa5090000 | WordBlock;	// sh $9, x($8)
				WordBlock += 2;
			}
		}
		
		code[c++] = 0x3c08B000;	// lui $8, 0xB000 # PingPong
		code[c++] = 0x35081080;	// ori $8, 0x1080
		code[c++] = 0x3c090000;														// lui $9, 0xAAAA # value
		code[c++] = 0x35290000 | devId << HS_SPI_SS_NUM | 
								 HS_SPI_PROFILE_PP0 << HS_SPI_PROFILE_NUM | 
								 HS_SPI_COMMAND_START_NOW << HS_SPI_COMMAND_VALUE;	// ori $9, 0x5555 # value
		code[c++] = 0xad090000;	// sw $9, 0($8)
		
		code[c++] = 0x03e00008; // jr $31
		code[c++] = 0x0;		// nop
		/*
		for (i=0; i<0x120; i++)
		{
			printf("X 0x%04x, 0x%08x, 0x%06x,\n", i, code[i], WordBlock );
		}
		printf("\n\n");
		*/
		ejtag_run_pracc( bus, code, c );
		//printf("3 0x%06x, 0x%06x, 0x%06x,\n", c, fcnt, WordBlock );
		
		// Wait...
		SendCmd(HS_SPI_OP_READ, FLASH_RDSR, 1, -1); // 0x5 Status Reg
		i = 0;
		//int t;
		// && operator dont work here !?!
		while ( (bus_read( bus, 0xb0001200 ) & 0x1000000) == 0x1000000 ) // 0x1 - WIP/RDY Bit
		{
			// t = bus_read( bus, 0xb0001200 );
			//printf("9 %x,%x,%x,%x.\n", t, t >> 24, t && 0x1000000, t & 0x1000000);
			SendCmd(HS_SPI_OP_READ, FLASH_RDSR, 1, -1); // 0x5 Status Reg
			if (i > 100)
			{
				printf("Timeout Error: Waiting for WIP bit in Status Reg 1\n");
				return 1;
			}
			i++;
		}
		//SendCmd(HS_SPI_OP_SLEEP, 0, 1, -1); // nop
		printf("Done 0x%06x / %d   ( %d%% )\n", fcnt, fcnt, fcnt / (fylesizeblock / 100) );
	}
	
	
	
	
	// 0xB0001100 = HsSpiProfile->clk_ctrl = 0x8100 = 50Mhz
	/* 0xB0001014 =
	HS_SPI->hs_spiFlashCtrl     = devId<<HS_SPI_FCTRL_SS_NUM | 
								0<<HS_SPI_FCTRL_PROFILE_NUM | 
								dummyBytes<<HS_SPI_FCTRL_DUMMY_BYTES |   (10)
								addrBytes<<HS_SPI_FCTRL_ADDR_BYTES |      (8)
								opCode<<HS_SPI_FCTRL_READ_OPCODE |        (0)
								multibitEn<<HS_SPI_FCTRL_MB_ENABLE;
	*/
	// 0x50B	in general 0x5XX
	
	
	
	
	/*
    unsigned char buf[256 + 6];
	buf[0] = 2; // write
	buf[1] = ((adr & 0x00ff0000) >> 16);
	buf[2] = ((adr & 0x0000ff00) >> 8);
	buf[3] =  (adr & 0x000000ff);
	buf[4] = 0xaa;
	buf[5] = 0x55;
	buf[6] = 0xaa;
	buf[7] = 0x55;
	*/
	//status = BcmSpi_Write( msg_buf, nbytes, spi_flash_busnum 0, SPI_FLASH_SLAVE_DEV_ID 0, spi_flash_clock 781000);
	//        BcmHsSpiWrite( msg_buf, nbytes, devId 0, freqHz 781000, bcmSpiCtrlState[devId] );
	//				hsSpiSetGlobalState(ctrlState);
	//				hsSpiSetProfile(ctrlState, freqHz 781000, 0, HS_SPI_PROFILE_PP0 1);
	//				hsSpiWriteP0(msg_buf, nbytes, devId 0);
	//					static int hsSpiWriteP0( const unsigned char *pTxBuf, int nbytes, int devId ) // 0xb0001200
	
	
    //buf[0] = FLASH_WREN;
	//bus_write( bus, 0xb0001200, ((HS_SPI_OP_WRITE << HS_SPI_OP_CODE) | nbytes) << 16 ); // FiFo0
	//my_spi_write(buf, 1) == SPI_STATUS_OK
	
	
	/*
	// Assuming unprotected   spi_flash_ub(sector)
	bus_write( bus, 0xb0001014, 0x502 ); // Write + 1/1 dumm/addr Bytes
	bus_write( bus, 0xb0001200, (FLASH_WREN << 8) ); // Write Enable
	
	bus_write( bus, 0xb0001014, 0x502 ); // Write + 1/1 dumm/addr Bytes
	bus_write( bus, 0xb0001200, ((HS_SPI_OP_WRITE << HS_SPI_OP_CODE) | nbytes) << 16 | (FLASH_WREN << 8) | FLASH_WREN); // FiFo0
	bus_write( bus, 0xb8010000, 0x12345678 );
	bus_write( bus, 0xb8000000, 0xffff0000 );
	bus_write( bus, 0xb0001080, 0x101 ); // PingPong
	usleep(100000);
	*/
	
/**/
//static int hsSpiReadP0( const unsigned char *pRxBuf, int prependcnt, int nbytes, int devId, int multiEn )
	
	//bus_write( bus, 0xb0001014, 0x50B ); // back to Fast Read + dumm/addr Bytes
	
		
		//bus_write( bus, 0xb0001000 | 0x80, cmd ); // PingPong
		//printf("write (0x%08x) = 0x%08X\n", 0xb0001000 | 0x80, cmd );
		
		//bus_write( bus, 0xb0001014, 0x50B ); // back to Fast Read + dumm/addr Bytes
		/*
		printf("HsSpiControl\n");
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001000, bus_read( bus, 0xb0001000 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001004, bus_read( bus, 0xb0001004 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001008, bus_read( bus, 0xb0001008 ) );
		printf("HS_SPI_PINGPONG 0\n");
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001080, bus_read( bus, 0xb0001080 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001084, bus_read( bus, 0xb0001084 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001088, bus_read( bus, 0xb0001088 ) );
		printf("FIFO 0\n");
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb0001200, bus_read( bus, 0xb0001200 ) );
		printf("Mem Map\n");
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb8000000, bus_read( bus, 0xb8000000 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb8000004, bus_read( bus, 0xb8000004 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb8010000, bus_read( bus, 0xb8010000 ) );
		printf("   bus_read(0x%08x) = 0x%08X\n", 0xb8010004, bus_read( bus, 0xb8010004 ) );
		*/
	//}
	
	
	
	printf("\nFinished, you may want to read the flash back & compare\n> readmem 0xb8000000 0x%x readback.bin\n\n", fylesizeblock);
	//usleep(500000);
	//}
	//return SPI_STATUS_OK;
	return 1;
}



/* Must read min 1 byte (but ignores the first 2 real input bytes) */
static void SendCmd( int ReadWrite, int OpCode, int nBytes, int addr )
{
	uint16_t i, msgCtrl;
	//uint32_t msgCtrl2 = 0, msgCtrl3 = 0;
	
	//msgCtrl = (HS_SPI_OP_READ_WRITE << HS_SPI_OP_CODE) | nbytes;	// HS_SPI_OP_READ = 3
	msgCtrl = (ReadWrite << HS_SPI_OP_CODE) | nBytes;
	//msgCtrl = (1 << 13) | nbytes;
	/*if (multiEn) {
	  msgCtrl |= (1<<11);
	}*/
	
	//HS_SPI_FIFO0[0] = (msgCtrl >> 8) & 0xFF;
	//HS_SPI_FIFO0[1] = (msgCtrl >> 0) & 0xFF;
	//bus_write( bus, 0xb0001000+0x200+0, (msgCtrl >> 8) & 0xFF);
	//bus_write( bus, 0xb0001000+0x200+1, (msgCtrl >> 0) & 0xFF);
	//printf("write (0x%08x) = 0x%08X\n", 0xb0001000 | 0x200, msgCtrl );
	//printf("write (0x%08x) = 0x%08X\n", 0xb0001000 | 0x200, msgCtrl2 );
	
	//for (;;) {
	//bus_write( bus, 0xb0001080, 0 ); // PingPong
	// The act of writing to FIFO will make it send (after pingpong cmd)... so only correct amount of bytes
	for (i=0; i<=1; i++) {
		ejtag_bus_writeXX( bus, 0xb0001200, msgCtrl, 16 );	// write twice, even in byte mode
		ejtag_bus_writeXX( bus, 0xb0001202, OpCode,   8 );
		if (addr != -1) { // 3 bytes of address
			ejtag_bus_writeXX( bus, 0xb0001203, addr >> 16, 8 );
			ejtag_bus_writeXX( bus, 0xb0001204, addr & 0xFFFF, 16 );
		}
		if (nBytes > 1) {
			ejtag_bus_writeXX( bus, 0xb0001206, 0x5555, 16 );
			ejtag_bus_writeXX( bus, 0xb0001208, 0xaaaaaaaa, 32 );
			ejtag_bus_writeXX( bus, 0xb000120c, 0x12345678, 32 );
		}
	}
	
	//bus_write( bus, 0xb0001200, (msgCtrl << 16) | (OpCode << 8) | 0xff );
	//bus_write( bus, 0xb0001200, (msgCtrl << 16) | (OpCode << 8) );
	//bus_write( bus, 0xb0001204, 0 << 8 );
	//bus_write( bus, 0xb0001204, addr << 8 );
//	bus_write( bus, 0xb0001208, rand() );
	//bus_write( bus, 0xb0001208, rand() );
	
	//bus_write( bus, 0xb0001000 | 0x200, (msgCtrl << 16) | 0x9F9F ); // FiFo0
	//usleep(1);
	//bus_write( bus, 0xb0001000 | 0x200, (msgCtrl << 16) | 0x9F9F ); // FiFo0
	//usleep(1);
	//bus_write( bus, 0xb0001000 | 0x200, (msgCtrl << 16) | 0x9F9F ); // FiFo0
	//usleep(1);
	//bus_write( bus, 0xb0001000 | 0x200, (msgCtrl << 16) | 0x9F9F ); // FiFo0
	
	
	/*
	// Read & Write
	HS_SPI_PINGPONG0->command = devId<<HS_SPI_SS_NUM | // mem location is 32 bit
								HS_SPI_PROFILE_PP0<<HS_SPI_PROFILE_NUM | 
								0<<HS_SPI_TRIGGER_NUM | 
								HS_SPI_COMMAND_START_NOW<<HS_SPI_COMMAND_VALUE;
	*/
	//for (devId=0; devId<=1; devId++) {
		uint32_t cmd = 	devId << HS_SPI_SS_NUM | 
								HS_SPI_PROFILE_PP0 << HS_SPI_PROFILE_NUM | 
								0 << HS_SPI_TRIGGER_NUM | 
								HS_SPI_COMMAND_START_NOW << HS_SPI_COMMAND_VALUE;
		bus_write( bus, 0xb0001000 | 0x80, cmd ); // PingPong
		/**/
		//printf("write (0x%08x) = 0x%08X\n", 0xb0001000 | 0x200, (msgCtrl << 16) | OpCode << 8 );
		//printf("write (0x%08x) = 0x%08X\n", 0xb0001000 | 0x080, cmd );
		//usleep(10);	// the instructions above always seem to run in high a speed
		//printf("   bus_read(0xB0001200) = 0x%08X\n", bus_read( bus, 0xb0001000 | 0x200 ) );
		
	//}
}



static void
cmd_poop_help( void )
{
	printf( _("Usage: %s [devID (0)] [FileName (cfe.bin)]\ntest read flash direct command.\n"), "poop" );
}

cmd_t cmd_poop = {
	"poop", N_("test flash"), cmd_poop_help, cmd_poop_run
};
